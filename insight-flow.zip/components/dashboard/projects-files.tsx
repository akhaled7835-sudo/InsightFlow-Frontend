import {
  FileSpreadsheet,
  FileText,
  FileJson,
  MoreHorizontal,
  ArrowUpRight,
} from 'lucide-react'

const projects = [
  { name: 'Q3 Revenue Analysis', team: 'Finance', progress: 82, status: 'On track', tone: 'text-success bg-success/15' },
  { name: 'Customer Churn Model', team: 'Data Science', progress: 47, status: 'In review', tone: 'text-warning bg-warning/15' },
  { name: 'Marketing Attribution', team: 'Growth', progress: 95, status: 'On track', tone: 'text-success bg-success/15' },
  { name: 'Product Usage Report', team: 'Product', progress: 31, status: 'At risk', tone: 'text-destructive bg-destructive/15' },
]

const files = [
  { name: 'q3_sales_report.xlsx', size: '2.4 MB', when: '2m ago', icon: FileSpreadsheet, tone: 'text-success' },
  { name: 'customer_export.csv', size: '890 KB', when: '1h ago', icon: FileText, tone: 'text-primary' },
  { name: 'analytics_config.json', size: '12 KB', when: '3h ago', icon: FileJson, tone: 'text-warning' },
  { name: 'churn_dataset.xlsx', size: '5.1 MB', when: 'Yesterday', icon: FileSpreadsheet, tone: 'text-success' },
]

export function RecentProjects() {
  return (
    <div className="glass rounded-2xl p-5">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h3 className="text-base font-semibold tracking-tight">Recent Projects</h3>
          <p className="text-sm text-muted-foreground">Active workspaces</p>
        </div>
        <button className="flex items-center gap-1 text-sm font-medium text-primary hover:underline">
          View all <ArrowUpRight className="h-3.5 w-3.5" />
        </button>
      </div>
      <div className="space-y-2">
        {projects.map((p) => (
          <div
            key={p.name}
            className="flex items-center gap-4 rounded-xl border border-border bg-background/40 p-3 transition-colors hover:border-primary/30"
          >
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <p className="truncate text-sm font-medium">{p.name}</p>
                <span className={`shrink-0 rounded-md px-1.5 py-0.5 text-xs font-medium ${p.tone}`}>
                  {p.status}
                </span>
              </div>
              <p className="mt-0.5 text-xs text-muted-foreground">{p.team}</p>
              <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-secondary">
                <div
                  className="h-full rounded-full bg-primary"
                  style={{ width: `${p.progress}%` }}
                />
              </div>
            </div>
            <span className="text-sm font-semibold tabular-nums">{p.progress}%</span>
            <button className="text-muted-foreground hover:text-foreground" aria-label="More">
              <MoreHorizontal className="h-4 w-4" />
            </button>
          </div>
        ))}
      </div>
    </div>
  )
}

export function RecentFiles() {
  return (
    <div className="glass rounded-2xl p-5">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h3 className="text-base font-semibold tracking-tight">Recent Uploads</h3>
          <p className="text-sm text-muted-foreground">Latest data files</p>
        </div>
        <button className="flex items-center gap-1 text-sm font-medium text-primary hover:underline">
          View all <ArrowUpRight className="h-3.5 w-3.5" />
        </button>
      </div>
      <div className="space-y-1.5">
        {files.map((f) => (
          <div
            key={f.name}
            className="flex items-center gap-3 rounded-xl border border-transparent p-2.5 transition-colors hover:border-border hover:bg-background/40"
          >
            <span className={`flex h-9 w-9 items-center justify-center rounded-lg bg-secondary ${f.tone}`}>
              <f.icon className="h-4.5 w-4.5" />
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium">{f.name}</p>
              <p className="text-xs text-muted-foreground">{f.size}</p>
            </div>
            <span className="text-xs text-muted-foreground">{f.when}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
