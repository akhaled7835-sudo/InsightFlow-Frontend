'use client'

import { Search, Bell, Menu, ChevronDown, Command } from 'lucide-react'
import { useState } from 'react'

export function Topbar({ onMenu }: { onMenu: () => void }) {
  const [notifOpen, setNotifOpen] = useState(false)

  return (
    <header className="sticky top-0 z-30 flex items-center gap-3 border-b border-border bg-background/80 px-4 py-3 backdrop-blur-md sm:px-6">
      <button
        onClick={onMenu}
        className="rounded-lg p-2 text-muted-foreground hover:bg-secondary lg:hidden"
        aria-label="Open menu"
      >
        <Menu className="h-5 w-5" />
      </button>

      {/* search */}
      <div className="relative flex-1 max-w-md">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <input
          type="text"
          placeholder="Search projects, files, reports..."
          className="h-10 w-full rounded-xl border border-border bg-card/60 pl-10 pr-16 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary/50 focus:outline-none focus:ring-2 focus:ring-primary/20"
        />
        <span className="pointer-events-none absolute right-3 top-1/2 hidden -translate-y-1/2 items-center gap-1 rounded-md border border-border bg-background px-1.5 py-0.5 text-xs text-muted-foreground sm:flex">
          <Command className="h-3 w-3" />K
        </span>
      </div>

      <div className="ml-auto flex items-center gap-2">
        {/* notifications */}
        <div className="relative">
          <button
            onClick={() => setNotifOpen((o) => !o)}
            className="relative rounded-lg p-2 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
            aria-label="Notifications"
          >
            <Bell className="h-5 w-5" />
            <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-primary ring-2 ring-background" />
          </button>
          {notifOpen && (
            <div className="absolute right-0 z-20 mt-2 w-80 rounded-xl border border-border bg-popover p-2 shadow-2xl shadow-black/40">
              <p className="px-2 py-1.5 text-sm font-medium">Notifications</p>
              {[
                { t: 'AI report ready', d: 'Q3 revenue analysis completed', time: '2m' },
                { t: 'New file processed', d: 'sales_data.csv cleaned & imported', time: '1h' },
                { t: 'Churn alert', d: '340 users flagged as at-risk', time: '3h' },
              ].map((n) => (
                <div
                  key={n.t}
                  className="flex items-start gap-3 rounded-lg px-2 py-2 hover:bg-secondary"
                >
                  <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-primary" />
                  <div className="min-w-0">
                    <p className="text-sm font-medium">{n.t}</p>
                    <p className="truncate text-xs text-muted-foreground">{n.d}</p>
                  </div>
                  <span className="ml-auto text-xs text-muted-foreground">{n.time}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* profile */}
        <button className="flex items-center gap-2 rounded-xl border border-border bg-card/60 py-1.5 pl-1.5 pr-2.5 transition-colors hover:border-primary/40">
          <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary text-xs font-semibold text-primary-foreground">
            SC
          </span>
          <span className="hidden text-left sm:block">
            <span className="block text-sm font-medium leading-tight">Sarah Chen</span>
            <span className="block text-xs leading-tight text-muted-foreground">Admin</span>
          </span>
          <ChevronDown className="hidden h-4 w-4 text-muted-foreground sm:block" />
        </button>
      </div>
    </header>
  )
}
