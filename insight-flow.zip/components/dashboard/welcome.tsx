import { Sparkles, Download } from 'lucide-react'

export function Welcome() {
  return (
    <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <p className="text-sm text-muted-foreground">Wednesday, September 24</p>
        <h1 className="mt-1 text-balance text-2xl font-semibold tracking-tight sm:text-3xl">
          Welcome back, Sarah
        </h1>
        <p className="mt-1 text-pretty text-muted-foreground">
          Here&apos;s what&apos;s happening across your workspace today.
        </p>
      </div>
      <div className="flex items-center gap-2">
        <button className="inline-flex h-10 items-center gap-2 rounded-xl border border-border bg-card/60 px-4 text-sm font-medium transition-colors hover:border-primary/40">
          <Download className="h-4 w-4" />
          Export
        </button>
        <button className="inline-flex h-10 items-center gap-2 rounded-xl bg-primary px-4 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90">
          <Sparkles className="h-4 w-4" />
          Generate Report
        </button>
      </div>
    </div>
  )
}
