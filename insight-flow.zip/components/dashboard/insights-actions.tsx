import {
  Sparkles,
  TrendingUp,
  AlertTriangle,
  Lightbulb,
  Upload,
  FileBarChart,
  Share2,
  Plus,
} from 'lucide-react'

const insights = [
  {
    icon: TrendingUp,
    tone: 'text-success',
    bg: 'bg-success/15',
    title: 'Revenue accelerating',
    body: 'Q3 grew 18.2% MoM, led by Enterprise in North America.',
  },
  {
    icon: AlertTriangle,
    tone: 'text-warning',
    bg: 'bg-warning/15',
    title: 'Churn risk detected',
    body: '340 accounts inactive 21+ days. Launch re-engagement?',
  },
  {
    icon: Lightbulb,
    tone: 'text-primary',
    bg: 'bg-primary/15',
    title: 'Optimization found',
    body: 'Bundling Pro + Analytics could lift AOV by ~$42.',
  },
]

const actions = [
  { label: 'Upload Data', icon: Upload },
  { label: 'New Report', icon: FileBarChart },
  { label: 'New Project', icon: Plus },
  { label: 'Share', icon: Share2 },
]

export function InsightsPanel() {
  return (
    <div className="glass relative overflow-hidden rounded-2xl p-5">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -right-16 -top-16 h-48 w-48 rounded-full bg-primary/15 blur-[80px]"
      />
      <div className="mb-4 flex items-center gap-2">
        <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/15 text-primary">
          <Sparkles className="h-4 w-4" />
        </span>
        <div>
          <h3 className="text-base font-semibold tracking-tight">AI Insights</h3>
          <p className="text-xs text-muted-foreground">Generated from your data</p>
        </div>
      </div>
      <div className="space-y-2.5">
        {insights.map((insight) => (
          <div
            key={insight.title}
            className="flex items-start gap-3 rounded-xl border border-border bg-background/40 p-3.5"
          >
            <span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${insight.bg} ${insight.tone}`}>
              <insight.icon className="h-4.5 w-4.5" />
            </span>
            <div>
              <p className="text-sm font-medium">{insight.title}</p>
              <p className="mt-0.5 text-sm leading-relaxed text-muted-foreground">
                {insight.body}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

export function QuickActions() {
  return (
    <div className="glass rounded-2xl p-5">
      <h3 className="mb-4 text-base font-semibold tracking-tight">Quick Actions</h3>
      <div className="grid grid-cols-2 gap-3">
        {actions.map((a) => (
          <button
            key={a.label}
            className="flex flex-col items-center justify-center gap-2 rounded-xl border border-border bg-background/40 py-5 text-sm font-medium transition-colors hover:border-primary/40 hover:bg-primary/10"
          >
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/15 text-primary">
              <a.icon className="h-5 w-5" />
            </span>
            {a.label}
          </button>
        ))}
      </div>
    </div>
  )
}
