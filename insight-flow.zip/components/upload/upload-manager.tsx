'use client'

import { useCallback, useRef, useState } from 'react'
import {
  UploadCloud,
  FileSpreadsheet,
  FileJson,
  FileText,
  CheckCircle2,
  AlertCircle,
  X,
  Loader2,
  Table2,
  Trash2,
  Database,
  Sheet,
  Plus,
  ArrowRight,
} from 'lucide-react'

type FileStatus = 'uploading' | 'success' | 'error'

type UploadFile = {
  id: string
  name: string
  size: number
  type: string
  progress: number
  status: FileStatus
  error?: string
  rows?: number
  columns?: number
}

const MAX_SIZE = 50 * 1024 * 1024 // 50MB
const ACCEPTED = ['csv', 'xlsx', 'xls', 'json']

const history = [
  { name: 'q3_revenue_2025.xlsx', size: '4.2 MB', rows: '12,480', date: 'Jul 22, 2026', type: 'xlsx' },
  { name: 'customer_segments.csv', size: '1.8 MB', rows: '8,204', date: 'Jul 20, 2026', type: 'csv' },
  { name: 'product_catalog.json', size: '920 KB', rows: '1,340', date: 'Jul 18, 2026', type: 'json' },
  { name: 'marketing_spend.csv', size: '2.1 MB', rows: '5,670', date: 'Jul 15, 2026', type: 'csv' },
]

const previewColumns = ['Order ID', 'Customer', 'Region', 'Product', 'Revenue', 'Date']
const previewRows = [
  ['#ORD-10482', 'Acme Corp', 'North America', 'Enterprise Plan', '$4,200.00', '2026-07-21'],
  ['#ORD-10483', 'Globex Inc', 'Europe', 'Pro Plan', '$890.00', '2026-07-21'],
  ['#ORD-10484', 'Initech', 'Asia Pacific', 'Team Plan', '$1,540.00', '2026-07-20'],
  ['#ORD-10485', 'Umbrella Co', 'North America', 'Enterprise Plan', '$4,200.00', '2026-07-20'],
  ['#ORD-10486', 'Soylent Ltd', 'Latin America', 'Pro Plan', '$890.00', '2026-07-19'],
]

function ext(name: string) {
  return name.split('.').pop()?.toLowerCase() ?? ''
}

function fileIcon(type: string, className = 'h-5 w-5') {
  if (type === 'json') return <FileJson className={className} />
  if (type === 'csv') return <FileText className={className} />
  return <FileSpreadsheet className={className} />
}

function formatSize(bytes: number) {
  if (bytes >= 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
  return `${(bytes / 1024).toFixed(0)} KB`
}

export function UploadManager() {
  const [dragging, setDragging] = useState(false)
  const [files, setFiles] = useState<UploadFile[]>([])
  const inputRef = useRef<HTMLInputElement>(null)

  const addFiles = useCallback((incoming: FileList | null) => {
    if (!incoming) return
    const next: UploadFile[] = []
    Array.from(incoming).forEach((f) => {
      const type = ext(f.name)
      const id = `${f.name}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`
      let status: FileStatus = 'uploading'
      let error: string | undefined

      if (!ACCEPTED.includes(type)) {
        status = 'error'
        error = 'Unsupported file type'
      } else if (f.size > MAX_SIZE) {
        status = 'error'
        error = 'File exceeds 50 MB limit'
      }

      next.push({
        id,
        name: f.name,
        size: f.size,
        type,
        progress: status === 'error' ? 100 : 0,
        status,
        error,
      })
    })

    setFiles((prev) => [...next, ...prev])

    // simulate upload progress for valid files
    next
      .filter((f) => f.status === 'uploading')
      .forEach((f) => {
        const interval = setInterval(() => {
          setFiles((prev) =>
            prev.map((item) => {
              if (item.id !== f.id) return item
              const nextProgress = Math.min(item.progress + Math.random() * 18 + 8, 100)
              if (nextProgress >= 100) {
                clearInterval(interval)
                return {
                  ...item,
                  progress: 100,
                  status: 'success',
                  rows: Math.floor(Math.random() * 12000 + 800),
                  columns: Math.floor(Math.random() * 12 + 4),
                }
              }
              return { ...item, progress: nextProgress }
            }),
          )
        }, 320)
      })
  }, [])

  const onDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      setDragging(false)
      addFiles(e.dataTransfer.files)
    },
    [addFiles],
  )

  const removeFile = (id: string) => setFiles((prev) => prev.filter((f) => f.id !== id))

  const hasSuccess = files.some((f) => f.status === 'success')

  return (
    <div className="flex flex-col gap-6">
      {/* Quick actions */}
      <div className="grid gap-4 sm:grid-cols-3">
        {[
          {
            title: 'Upload New Dataset',
            desc: 'Drag & drop or browse files',
            icon: UploadCloud,
            primary: true,
            onClick: () => inputRef.current?.click(),
          },
          {
            title: 'Connect Database',
            desc: 'PostgreSQL, MySQL, Snowflake',
            icon: Database,
          },
          {
            title: 'Import from Google Sheets',
            desc: 'Sync a spreadsheet URL',
            icon: Sheet,
          },
        ].map((action) => (
          <button
            key={action.title}
            onClick={action.onClick}
            className={`group flex items-center gap-4 rounded-2xl border p-4 text-left transition-all hover:-translate-y-0.5 ${
              action.primary
                ? 'border-primary/40 bg-primary/10 hover:border-primary/60'
                : 'border-border bg-card/50 hover:border-primary/40'
            }`}
          >
            <span
              className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl transition-colors ${
                action.primary
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-secondary text-foreground group-hover:bg-primary/15 group-hover:text-primary'
              }`}
            >
              <action.icon className="h-5 w-5" />
            </span>
            <span className="min-w-0">
              <span className="flex items-center gap-1 text-sm font-medium">
                {action.title}
                <ArrowRight className="h-3.5 w-3.5 opacity-0 transition-opacity group-hover:opacity-100" />
              </span>
              <span className="block truncate text-xs text-muted-foreground">{action.desc}</span>
            </span>
          </button>
        ))}
      </div>

      {/* Dropzone */}
      <div
        onDragOver={(e) => {
          e.preventDefault()
          setDragging(true)
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={onDrop}
        className={`relative flex flex-col items-center justify-center gap-4 rounded-2xl border-2 border-dashed p-10 text-center transition-all ${
          dragging
            ? 'border-primary bg-primary/10'
            : 'border-border bg-card/40 hover:border-primary/40'
        }`}
      >
        <span
          className={`flex h-16 w-16 items-center justify-center rounded-2xl transition-transform ${
            dragging ? 'scale-110 bg-primary text-primary-foreground' : 'bg-primary/15 text-primary'
          }`}
        >
          <UploadCloud className="h-8 w-8" />
        </span>
        <div>
          <p className="text-base font-semibold text-balance">
            {dragging ? 'Drop your files to upload' : 'Drag & drop your files here'}
          </p>
          <p className="mt-1 text-sm text-muted-foreground">
            or click browse to select from your computer
          </p>
        </div>
        <button
          onClick={() => inputRef.current?.click()}
          className="inline-flex items-center gap-2 rounded-xl bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
        >
          <Plus className="h-4 w-4" />
          Browse Files
        </button>
        <input
          ref={inputRef}
          type="file"
          multiple
          accept=".csv,.xlsx,.xls,.json"
          className="hidden"
          onChange={(e) => addFiles(e.target.files)}
        />

        <div className="mt-2 flex flex-wrap items-center justify-center gap-2 text-xs text-muted-foreground">
          {['CSV', 'XLSX', 'XLS', 'JSON'].map((t) => (
            <span
              key={t}
              className="inline-flex items-center gap-1 rounded-full border border-border bg-background/60 px-2.5 py-1 font-medium"
            >
              <CheckCircle2 className="h-3 w-3 text-[color:var(--color-success)]" />
              {t}
            </span>
          ))}
          <span className="px-1">•</span>
          <span>Max file size 50 MB</span>
        </div>
      </div>

      {/* Empty state */}
      {files.length === 0 && (
        <div className="flex flex-col items-center gap-3 rounded-2xl border border-border bg-card/30 px-6 py-10 text-center">
          <img
            src="/upload-empty-state.png"
            alt="No datasets uploaded yet"
            className="h-32 w-32 object-contain opacity-90"
          />
          <p className="text-sm font-medium">No active uploads yet</p>
          <p className="max-w-sm text-sm text-muted-foreground text-pretty">
            Upload a CSV, Excel, or JSON file to see live progress, validation, and an instant
            dataset preview here.
          </p>
        </div>
      )}

      {/* Active uploads */}
      {files.length > 0 && (
        <div className="flex flex-col gap-3">
          <h3 className="text-sm font-semibold">Uploading &amp; recent</h3>
          <div className="flex flex-col gap-2">
            {files.map((f) => (
              <div
                key={f.id}
                className="animate-float-up rounded-xl border border-border bg-card/50 p-4"
              >
                <div className="flex items-center gap-3">
                  <span
                    className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-lg ${
                      f.status === 'error'
                        ? 'bg-[color:var(--color-error)]/15 text-[color:var(--color-error)]'
                        : f.status === 'success'
                          ? 'bg-[color:var(--color-success)]/15 text-[color:var(--color-success)]'
                          : 'bg-primary/15 text-primary'
                    }`}
                  >
                    {fileIcon(f.type)}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <p className="truncate text-sm font-medium">{f.name}</p>
                      <button
                        onClick={() => removeFile(f.id)}
                        className="rounded-md p-1 text-muted-foreground hover:bg-secondary hover:text-foreground"
                        aria-label={`Remove ${f.name}`}
                      >
                        {f.status === 'uploading' ? (
                          <X className="h-4 w-4" />
                        ) : (
                          <Trash2 className="h-4 w-4" />
                        )}
                      </button>
                    </div>
                    <div className="mt-1 flex items-center gap-2 text-xs text-muted-foreground">
                      <span>{formatSize(f.size)}</span>
                      {f.status === 'success' && f.rows && (
                        <>
                          <span>•</span>
                          <span>
                            {f.rows.toLocaleString()} rows · {f.columns} columns
                          </span>
                        </>
                      )}
                    </div>

                    {/* progress / status */}
                    {f.status === 'uploading' && (
                      <div className="mt-2 flex items-center gap-2">
                        <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-secondary">
                          <div
                            className="h-full rounded-full bg-primary transition-all duration-300"
                            style={{ width: `${f.progress}%` }}
                          />
                        </div>
                        <span className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Loader2 className="h-3 w-3 animate-spin" />
                          {Math.round(f.progress)}%
                        </span>
                      </div>
                    )}
                    {f.status === 'success' && (
                      <p className="mt-1.5 flex items-center gap-1 text-xs font-medium text-[color:var(--color-success)]">
                        <CheckCircle2 className="h-3.5 w-3.5" />
                        Uploaded &amp; validated
                      </p>
                    )}
                    {f.status === 'error' && (
                      <p className="mt-1.5 flex items-center gap-1 text-xs font-medium text-[color:var(--color-error)]">
                        <AlertCircle className="h-3.5 w-3.5" />
                        {f.error}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Dataset preview */}
      <div className="rounded-2xl border border-border bg-card/50">
        <div className="flex items-center justify-between border-b border-border px-5 py-4">
          <div className="flex items-center gap-2">
            <Table2 className="h-4 w-4 text-primary" />
            <h3 className="text-sm font-semibold">Dataset Preview</h3>
          </div>
          {hasSuccess ? (
            <span className="rounded-full bg-[color:var(--color-success)]/15 px-2.5 py-1 text-xs font-medium text-[color:var(--color-success)]">
              Ready to analyze
            </span>
          ) : (
            <span className="text-xs text-muted-foreground">Sample data</span>
          )}
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-border">
                {previewColumns.map((col) => (
                  <th
                    key={col}
                    className="whitespace-nowrap px-5 py-3 text-xs font-medium uppercase tracking-wider text-muted-foreground"
                  >
                    {col}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {previewRows.map((row, i) => (
                <tr
                  key={i}
                  className="border-b border-border/60 last:border-0 hover:bg-secondary/40"
                >
                  {row.map((cell, j) => (
                    <td
                      key={j}
                      className={`whitespace-nowrap px-5 py-3 ${
                        j === 0 ? 'font-medium text-foreground' : 'text-muted-foreground'
                      }`}
                    >
                      {cell}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Upload history */}
      <div className="rounded-2xl border border-border bg-card/50">
        <div className="flex items-center justify-between border-b border-border px-5 py-4">
          <h3 className="text-sm font-semibold">Upload History</h3>
          <button className="text-xs font-medium text-primary hover:underline">View all</button>
        </div>
        <ul className="divide-y divide-border/60">
          {history.map((h) => (
            <li
              key={h.name}
              className="flex items-center gap-4 px-5 py-3.5 transition-colors hover:bg-secondary/40"
            >
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-secondary text-muted-foreground">
                {fileIcon(h.type, 'h-4 w-4')}
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium">{h.name}</p>
                <p className="text-xs text-muted-foreground">
                  {h.size} · {h.rows} rows
                </p>
              </div>
              <span className="hidden text-xs text-muted-foreground sm:block">{h.date}</span>
              <span className="flex items-center gap-1 rounded-full bg-[color:var(--color-success)]/15 px-2.5 py-1 text-xs font-medium text-[color:var(--color-success)]">
                <CheckCircle2 className="h-3 w-3" />
                Processed
              </span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}
